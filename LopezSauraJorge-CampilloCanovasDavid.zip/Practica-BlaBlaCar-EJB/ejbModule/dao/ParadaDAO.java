package dao;

import java.util.Date;

import model.ParadaJPA;

public interface ParadaDAO {
	public ParadaJPA createParadaOrigen(int idViaje, String ciudad, String calle,int CP, Date fecha);
	public ParadaJPA createParadaDestino(int idViaje, String ciudad, String calle, int CP, Date fecha);
}
