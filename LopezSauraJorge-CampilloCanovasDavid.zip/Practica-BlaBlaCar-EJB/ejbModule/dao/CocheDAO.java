package dao;

import model.Coche;
import model.Usuario;

public interface CocheDAO {
	
	Coche createCoche(Usuario usuario, String matricula, String modelo, int a�o, int confort);

}
