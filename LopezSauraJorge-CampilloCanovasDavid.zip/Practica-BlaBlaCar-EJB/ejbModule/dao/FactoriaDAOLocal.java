package dao;

import javax.ejb.Local;

@Local
public interface FactoriaDAOLocal {

	UsuarioDAO getUsuarioDAO();
	CocheDAO getCocheDAO();
	ParadaDAO getParadaDAO();
	ReservaDAO getReservaDAO();
	ViajeDAO getViajeDAO();
	void setFactoriaDAO(int tipo);
	
}
