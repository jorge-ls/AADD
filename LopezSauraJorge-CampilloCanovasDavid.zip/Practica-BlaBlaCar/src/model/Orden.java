package model;

public enum Orden {
	ASCENDENTE, DESCENDENTE, NINGUNO
}
