package model;

public enum EstadoReserva {
	PENDIENTE,	ACEPTADA,RECHAZADA;

}
